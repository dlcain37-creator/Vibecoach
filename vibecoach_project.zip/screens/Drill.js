import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
export default function Drill(){return(<View style={styles.c}><Text style={styles.h}>Daily Drill 🔥</Text><Text style={styles.t}>Timer + posture camera coming soon.</Text></View>);}const styles=StyleSheet.create({c:{flex:1,justifyContent:'center',alignItems:'center'},h:{fontSize:28,fontWeight:'700'},t:{fontSize:16}});