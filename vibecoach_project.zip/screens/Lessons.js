import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
export default function Lessons(){return(<View style={styles.c}><Text style={styles.h}>Lessons 📚</Text><Text style={styles.t}>Body language • Eye contact • Voice</Text></View>);}const styles=StyleSheet.create({c:{flex:1,justifyContent:'center',alignItems:'center'},h:{fontSize:28,fontWeight:'700'},t:{fontSize:16}});