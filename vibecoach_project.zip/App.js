import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Home from './screens/Home';
import Drill from './screens/Drill';
import Lessons from './screens/Lessons';
import Voice from './screens/Voice';
import Stats from './screens/Stats';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator screenOptions={{ headerShown: false }}>
        <Tab.Screen name="Home" component={Home} />
        <Tab.Screen name="Drill" component={Drill} />
        <Tab.Screen name="Lessons" component={Lessons} />
        <Tab.Screen name="Voice" component={Voice} />
        <Tab.Screen name="Stats" component={Stats} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}